package com.ipi.tpjava;


import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.widget.SeekBar;
import android.os.Bundle;
import android.widget.TextView;


public class ColorChooser extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_chooser);

        // SeekBars
        final SeekBar seekBarR = findViewById(R.id.seekBarR);
        final SeekBar seekBarG = findViewById(R.id.seekBarG);
        final SeekBar seekBarB = findViewById(R.id.seekBarB);

        final SeekBar seekBarH = findViewById(R.id.seekBarH);
        final SeekBar seekBarS = findViewById(R.id.seekBarS);
        final SeekBar seekBarV = findViewById(R.id.seekBarV);

        // Colored square
        final TextView generatedColorView = findViewById(R.id.generatedColor);

        // RGB
        final int[] rgb = { seekBarR.getProgress(), seekBarG.getProgress(), seekBarB.getProgress() };

        // HSL
        final float[] hsv = { seekBarH.getProgress(), seekBarS.getProgress(), seekBarV.getProgress() };

        final int[] currentSB = { 0 };

        // RED
        seekBarR.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(currentSB[0] == 1){
                    rgb[0] = seekBar.getProgress();
                    generatedColorView.setBackgroundColor(Color.parseColor(generateColor(rgb[0], rgb[1], rgb[2])));
                    Color.RGBToHSV(rgb[0], rgb[1], rgb[2], hsv);
                    generatedColorView.setText(toDislplay(rgb, hsv));

                    seekBarH.setProgress((int)hsv[0]);
                    seekBarS.setProgress((int)(hsv[1]*100));
                    seekBarV.setProgress((int)(hsv[2]*100));
                }
            }
            public void onStartTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 1;
            }
            public void onStopTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 0;
            }
        });

        // GREEN
        seekBarG.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(currentSB[0] == 2) {
                    rgb[1] = seekBar.getProgress();
                    generatedColorView.setBackgroundColor(Color.parseColor(generateColor(rgb[0], rgb[1], rgb[2])));
                    Color.RGBToHSV(rgb[0], rgb[1], rgb[2], hsv);
                    generatedColorView.setText(toDislplay(rgb, hsv));

                    seekBarH.setProgress((int) hsv[0]);
                    seekBarS.setProgress((int) (hsv[1] * 100));
                    seekBarV.setProgress((int) (hsv[2] * 100));
                }
            }
            public void onStartTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 2;
            }
            public void onStopTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 0;
            }
        });

        // BLUE
        seekBarB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(currentSB[0] == 3) {
                    rgb[2] = seekBar.getProgress();
                    generatedColorView.setBackgroundColor(Color.parseColor(generateColor(rgb[0], rgb[1], rgb[2])));
                    Color.RGBToHSV(rgb[0], rgb[1], rgb[2], hsv);
                    generatedColorView.setText(toDislplay(rgb, hsv));

                    seekBarH.setProgress((int) hsv[0]);
                    seekBarS.setProgress((int) (hsv[1] * 100));
                    seekBarV.setProgress((int) (hsv[2] * 100));
                }
            }
            public void onStartTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 3;
            }
            public void onStopTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 0;
            }
        });



        // HUE
        seekBarH.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(currentSB[0] == 4){
                    hsv[0] = seekBar.getProgress();
                    generatedColorView.setBackgroundColor(Color.HSVToColor(hsv));

                    rgb[0] = Color.red(Color.HSVToColor(hsv));
                    rgb[1] = Color.green(Color.HSVToColor(hsv));
                    rgb[2] = Color.blue(Color.HSVToColor(hsv));

                    generatedColorView.setText(toDislplay(rgb, hsv));

                    seekBarR.setProgress(rgb[0]);
                    seekBarG.setProgress(rgb[1]);
                    seekBarB.setProgress(rgb[2]);
                }
            }
            public void onStartTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 4;
            }
            public void onStopTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 0;
            }
        });

        // SATURATION
        seekBarS.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(currentSB[0] == 5) {
                    hsv[1] = (float) seekBar.getProgress() / 100;
                    generatedColorView.setBackgroundColor(Color.HSVToColor(hsv));

                    rgb[0] = Color.red(Color.HSVToColor(hsv));
                    rgb[1] = Color.green(Color.HSVToColor(hsv));
                    rgb[2] = Color.blue(Color.HSVToColor(hsv));

                    generatedColorView.setText(toDislplay(rgb, hsv));

                    seekBarR.setProgress(rgb[0]);
                    seekBarG.setProgress(rgb[1]);
                    seekBarB.setProgress(rgb[2]);
                }
            }
            public void onStartTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 5;
            }
            public void onStopTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 0;
            }
        });

        // VALUE
        seekBarV.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(currentSB[0] == 6) {
                    hsv[2] = (float) seekBar.getProgress() / 100;
                    generatedColorView.setBackgroundColor(Color.HSVToColor(hsv));

                    rgb[0] = Color.red(Color.HSVToColor(hsv));
                    rgb[1] = Color.green(Color.HSVToColor(hsv));
                    rgb[2] = Color.blue(Color.HSVToColor(hsv));

                    generatedColorView.setText(toDislplay(rgb, hsv));

                    seekBarR.setProgress(rgb[0]);
                    seekBarG.setProgress(rgb[1]);
                    seekBarB.setProgress(rgb[2]);
                }
            }
            public void onStartTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 6;
            }
            public void onStopTrackingTouch(SeekBar seekBar) {
                currentSB[0] = 0;
            }
        });
    }

    public String generateColor(int r, int g, int b){
        return String.format("#%02x%02x%02x", r, g, b);
    }

    public String toDislplay(int[] rgb, float[] hsv){
        return "RGB(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + ") / HSV(" + (int)hsv[0] + "°," + (int)(hsv[1]*100) + "%," + (int)(hsv[2]*100) + "%)";
    }
}
